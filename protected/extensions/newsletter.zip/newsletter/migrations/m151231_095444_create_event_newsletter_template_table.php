<?php

class m151231_095444_create_event_newsletter_template_table extends CDbMigration
{
	public function up()
	{
		$this->createTable('event_newsletter_template', array(
            'id' => 'pk',
            'eventid' => 'integer NOT NULL',
            'newsletterid' => 'integer NOT NULL'
        ));
	}

	public function down()
	{
		$this->dropTable('event_newsletter_template');
	}

	/*
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	}

	public function safeDown()
	{
	}
	*/
}