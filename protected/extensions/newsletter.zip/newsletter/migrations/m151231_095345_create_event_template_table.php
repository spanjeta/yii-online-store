<?php

class m151231_095345_create_event_template_table extends CDbMigration
{
	public function up()
	{
		$this->createTable('event_template', array(
            'id' => 'pk',
            'event' => 'string NOT NULL',
        ));
	}

	public function down()
	{
		$this->dropTable('event_template');
	}

	/*
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	}

	public function safeDown()
	{
	}
	*/
}