<?php

class m151231_095410_create_newsletter_template_table extends CDbMigration
{
	public function up()
	{
		$this->createTable('newsletter_template', array(
            'id' => 'pk',
            'title' => 'string NOT NULL',
            'code' => 'string NOT NULL',
            'message' => 'longtext NOT NULL',
            'variable_info' => 'string NOT NULL',
            'status' => 'char NOT NULL'
        ));
	}

	public function down()
	{
		$this->dropTable('newsletter_template');
	}

	/*
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	}

	public function safeDown()
	{
	}
	*/
}