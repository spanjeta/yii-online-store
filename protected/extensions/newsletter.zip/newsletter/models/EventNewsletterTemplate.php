<?php

/**
 * This is the model class for table "event_newsletter_template".
 *
 * The followings are the available columns in table 'event_newsletter_template':
 * @property string $id
 * @property string $eventid
 * @property string $newsletterid
 */
class EventNewsletterTemplate extends CActiveRecord
{
	public $eventname;
	public $newslettername;

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'event_newsletter_template';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('eventid, newsletterid', 'required'),
			array('eventid, newsletterid', 'length', 'max'=>255),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, eventid, newsletterid, eventname , newslettername', 'safe', 'on'=>'search'),
			array('eventid','validateEvent','safe'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'newsletter' => array(self::BELONGS_TO ,'NewsletterTemplate','newsletterid'),
			'event' => array(self::BELONGS_TO,'EventTemplate','eventid'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'eventid' => 'Eventid',
			'newsletterid' => 'Newsletterid',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;
		$criteria->with = array( 'event', 'newsletter');

		$criteria->compare('t.id',$this->id,true);
		$criteria->compare('event.event',$this->eventname,true);
		$criteria->compare('newsletter.title',$this->newslettername,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			'sort'=>array(
        		'attributes'=>array(
            	'eventname'=>array(
                	'asc'=>'event.event',
                	'desc'=>'event.event DESC',
            ),
            '*',
        ),
    ),
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return EventNewsletterTemplate the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function getEvent()
    {
        $event = EventTemplate::model()->findAll(
                array('order'=>'event'));
        $eventArray = CHtml::listData($event,'id','event');
        return $eventArray;
    }

    public function getNewsletter()
    {
        $newsletter = NewsletterTemplate::model()->findAll(
                array('order'=>'title'));
        $newsletterArray = CHtml::listData($newsletter,'id','title');
        return $newsletterArray;
    }

    public function validateEvent($attribute , $params) {
    	if($this->eventid !== null) {
            $query = EventNewsletterTemplate::model()->findByAttributes(array('eventid'=>$this->eventid));
            if(!empty($query)) {
                $this->addError($attribute,'This EVent Has Already Assigned a Template..');
            }
        }
    }
}
