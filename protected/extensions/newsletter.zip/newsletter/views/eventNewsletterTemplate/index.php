<?php
/* @var $this EventNewsletterTemplateController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Event Newsletter Templates',
);

$this->menu=array(
	array('label'=>'Create EventNewsletterTemplate', 'url'=>array('create')),
	array('label'=>'Manage EventNewsletterTemplate', 'url'=>array('admin')),
);
?>

<h1>Event Newsletter Templates</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
