<?php
/* @var $this EventNewsletterTemplateController */
/* @var $data EventNewsletterTemplate */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('eventid')); ?>:</b>
	<?php echo CHtml::encode(CHtml::encode($data->event['event'])); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('newsletterid')); ?>:</b>
	<?php echo CHtml::encode(CHtml::encode($data->newsletter['title'])); ?>
	<br />


</div>