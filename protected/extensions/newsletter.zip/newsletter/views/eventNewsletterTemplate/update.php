<?php
/* @var $this EventNewsletterTemplateController */
/* @var $model EventNewsletterTemplate */

$this->breadcrumbs=array(
	'Event Newsletter Templates'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List EventNewsletterTemplate', 'url'=>array('index')),
	array('label'=>'Create EventNewsletterTemplate', 'url'=>array('create')),
	array('label'=>'View EventNewsletterTemplate', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage EventNewsletterTemplate', 'url'=>array('admin')),
);
?>

<h1>Update EventNewsletterTemplate <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>