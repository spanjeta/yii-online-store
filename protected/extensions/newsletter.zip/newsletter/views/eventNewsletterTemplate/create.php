<?php
/* @var $this EventNewsletterTemplateController */
/* @var $model EventNewsletterTemplate */

$this->breadcrumbs=array(
	'Event Newsletter Templates'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List EventNewsletterTemplate', 'url'=>array('index')),
	array('label'=>'Manage EventNewsletterTemplate', 'url'=>array('admin')),
);
?>

<h1>Create EventNewsletterTemplate</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>