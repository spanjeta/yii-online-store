<?php
/* @var $this NewsletterTemplateController */
/* @var $model NewsletterTemplate */

$this->breadcrumbs=array(
	'Newsletter Templates'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List NewsletterTemplate', 'url'=>array('index')),
	array('label'=>'Manage NewsletterTemplate', 'url'=>array('admin')),
);
?>

<h1>Create NewsletterTemplate</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>