<?php
/* @var $this NewsletterTemplateController */
/* @var $model NewsletterTemplate */

$this->breadcrumbs=array(
	'Newsletter Templates'=>array('index'),
	$model->title=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List NewsletterTemplate', 'url'=>array('index')),
	array('label'=>'Create NewsletterTemplate', 'url'=>array('create')),
	array('label'=>'View NewsletterTemplate', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage NewsletterTemplate', 'url'=>array('admin')),
);
?>

<h1>Update NewsletterTemplate <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>